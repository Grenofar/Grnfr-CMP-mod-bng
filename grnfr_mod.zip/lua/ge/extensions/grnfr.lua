-- GRNFR Mod : extension GE principale (orchestration uniquement).
local M = {}
M.dependencies = { 'grnfr_sessionlog', 'grnfr_settings', 'grnfr_perf', 'grnfr_mode', 'grnfr_keys', 'grnfr_stutter', 'grnfr_traffic', 'grnfr_chase' }

local VERSION = '0.9.0'
local uiAttached = false
local consumers = {} -- UI abonnées (angular, panel, overlay) : on ne pousse des données que si au moins une est ouverte
local hudOpen = false
local bigOpen = false -- grande fenêtre en jeu (bouton Option du HUD)
local acc = 0
local cntPre, cntUpd, cntPoll, cntSent = 0, 0, 0, 0 -- compteurs de diagnostic (log toutes les 5 s + affichés dans le HUD)
local modeInfo = { id = 'menu', label = 'Menu principal', session = false }
local lastSig = ''
local notified, notifyAcc = false, 0
local modeAcc = 0
local staticAcc = 0 -- secondes depuis le dernier envoi de l'état à l'UI (renvoi de sécurité chaque seconde)
local function slog(kind, msg) local sl = rawget(_G, 'grnfr_sessionlog') if sl then pcall(sl.add, kind, msg) end end
local wasSession, lastModeEn = false, nil
local sessionAge = 0 -- secondes écoulées depuis le début de la partie (sert à réarmer le trafic adaptatif)

local MODE_LABELS = {
  menu = { 'Menu principal', 'Main menu' }, career = { 'Carrière', 'Career' },
  freeroam = { 'Jeu libre', 'Free roam' }, scenario = { 'Scénario', 'Scenario' },
  garage = { 'Garage', 'Garage' }, bus = { 'Bus', 'Bus' }, rally = { 'Rallye', 'Rally' },
  multiplayer = { 'Multijoueur', 'Multiplayer' }, localmp = { 'Multijoueur local', 'Local multiplayer' },
  startexp = { 'Expérience de démarrage', 'Starting experience' },
  session = { 'Session active (mode inconnu)', 'Active session (unknown mode)' },
}
local function L(fr, en) return (grnfr_settings.get().lang == 'en') and en or fr end
local function modeLabel()
  local parts = {}
  for _, id in ipairs(modeInfo.ids or {}) do
    local m = MODE_LABELS[id]
    parts[#parts + 1] = m and L(m[1], m[2]) or (modeInfo.raw or id)
  end
  if #parts == 0 then return modeInfo.label end
  return table.concat(parts, ' · ')
end

local function modeLabelEn()
  local parts = {}
  for _, id in ipairs(modeInfo.ids or {}) do
    local m = MODE_LABELS[id]
    parts[#parts + 1] = m and m[2] or (modeInfo.raw or id)
  end
  if #parts == 0 then return 'Unknown' end
  return table.concat(parts, ' + ')
end
local function levelName()
  local ok, n = pcall(function() return getMissionFilename() end)
  if ok and type(n) == 'string' then
    local lv = n:match('levels/([^/\\]+)')
    if lv then return lv end
  end
  return 'unknown'
end

-- Reads the game mode and keeps the session log in step: a session starts when a map is loaded, ends when it is left.
local function refreshMode()
  modeInfo = grnfr_mode.detect()
  if not modeInfo.session then hudOpen = false; bigOpen = false end
  if modeInfo.session and not wasSession then
    wasSession, lastModeEn = true, modeLabelEn()
    pcall(grnfr_sessionlog.begin, { mode = lastModeEn, map = levelName(), modVersion = VERSION,
      gameVersion = rawget(_G, 'beamng_versionb') or rawget(_G, 'beamng_version') })
    slog('info', 'Detection details: ' .. tostring(modeInfo.diag))
  elseif not modeInfo.session and wasSession then
    wasSession = false
    pcall(grnfr_sessionlog.finish, 'You left the map.')
  elseif wasSession then
    local m = modeLabelEn()
    if m ~= lastModeEn then
      slog('info', 'Game mode changed: ' .. lastModeEn .. ' -> ' .. m .. '.')
      slog('info', 'Detection details: ' .. tostring(modeInfo.diag))
      lastModeEn = m
    end
  end
end

-- Chase autorisé en jeu libre, mais aussi quand le mode est inconnu (session / raw / localmp / startexp) :
-- seuls les modes exclusifs (carrière, scénario, mission, bus, rallye, garage, multijoueur en ligne) le bloquent.
local BLOCKING = { career = true, scenario = true, mission = true, bus = true, rally = true, garage = true, multiplayer = true }
local function isFreeroam()
  if not modeInfo.session then return false end
  for _, id in ipairs(modeInfo.ids or {}) do if BLOCKING[id] then return false end end
  return true
end
-- État complet envoyé à l'UI : soit poussé (événement GRNFRStatic), soit renvoyé directement par getState/requestState.
local function buildStatic()
  return {
    version = VERSION,
    session = modeInfo.session,
    mode = modeLabel(),
    modeId = modeInfo.id,
    modeIds = modeInfo.ids,
    modeRaw = modeInfo.raw,
    chaseAllowed = isFreeroam(),
    hudOpen = hudOpen,
    bigOpen = bigOpen,
    traffic = grnfr_traffic.status(),
    chase = grnfr_chase.status(),
    hooks = cntPre + cntUpd,
    angular = consumers.angular == true, -- app HUD AngularJS placée par le joueur : le HUD Vue s'efface alors
    keyLabel = grnfr_keys.getDisplay(),
    settings = grnfr_settings.get(),
  }
end
local function pushStatic(force) guihooks.trigger('GRNFRStatic', buildStatic()) end

-- Appelé par l'action clavier "grnfr_toggle" (système d'actions officiel).
local function toast(msg)
  pcall(function() guihooks.trigger('toastrMsg', { type = 'info', title = 'GRNFR Mod', msg = msg }) end)
end

function M.toggleHud()
  refreshMode()
  if not modeInfo.session then
    toast(L("Le HUD GRNFR s'ouvre uniquement en partie (une carte doit être chargée).", 'The GRNFR HUD only opens in-game (a map must be loaded).'))
    return
  end
  if not grnfr_settings.get().hudEnabled then
    slog('info', 'You pressed ' .. grnfr_keys.getDisplay() .. ' but the HUD is turned off in Settings.')
    toast(L('HUD désactivé : activez-le dans GRNFR Mod > Paramètres.', 'HUD disabled: enable it in GRNFR Mod > Settings.'))
    return
  end
  if bigOpen then -- la grande fenêtre est ouverte : K la ferme (et le petit HUD ne revient pas)
    bigOpen, hudOpen = false, false
    slog('info', 'You closed the big window (' .. grnfr_keys.getDisplay() .. ').')
  else
    hudOpen = not hudOpen
    slog('info', hudOpen and ('You opened the small HUD (' .. grnfr_keys.getDisplay() .. ').') or ('You closed the small HUD (' .. grnfr_keys.getDisplay() .. ').'))
  end
  pushStatic(true) -- envoyé même si aucune UI n'est encore abonnée (le HUD Vue s'abonne en recevant l'état)
end

-- Bouton « Option » du HUD : le petit HUD disparaît, la grande fenêtre apparaît (K pour la fermer).
function M.openBig()
  refreshMode()
  if not modeInfo.session then return false end
  bigOpen, hudOpen = true, false
  slog('info', 'You opened the big window (Option button).')
  toast(L('Pour fermer l\'interface, appuyez sur ', 'To close the interface, press ') .. grnfr_keys.getDisplay() .. '.')
  pushStatic(true)
  return true
end
function M.closeBig() bigOpen = false; slog('info', 'You closed the big window.'); pushStatic(true); return true end

-- Configs de jeu (section Gameplay). Chase : uniquement en jeu libre.
function M.chaseStart(role)
  refreshMode()
  if not modeInfo.session or not isFreeroam() then
    slog('warn', 'Chase was not started: it is not available in the current game mode (' .. modeLabelEn() .. ').')
    toast(L('Chase : disponible uniquement en jeu libre.', 'Chase: free roam only.'))
    return false
  end
  bigOpen, hudOpen = false, true -- le petit HUD (avec le bouton Relancer) reste visible pendant le chase
  grnfr_chase.start(role)
  pushStatic(true)
  return true
end
function M.chaseRestart() grnfr_chase.restart(); pushStatic(true); return true end
function M.chaseStop() grnfr_chase.stop(); pushStatic(true); return true end
function M.chaseGo() grnfr_chase.go(); pushStatic(true); return true end

-- Appelé par l'UI au chargement de l'application.
local function onlyOverlay()
  local n = 0
  for _ in pairs(consumers) do n = n + 1 end
  return n == 1 and consumers.overlay == true
end
-- Cadence rapide (à chaque image) seulement si le HUD est ouvert ou si une UI détaillée (fenêtre, app) s'est abonnée.
-- Sinon : une mesure toutes les 0,5 s, envoyée même sans abonnement (l'abonnement UI -> Lua n'est pas fiable).
local function needFast()
  if hudOpen then return true end
  for id in pairs(consumers) do if id ~= 'overlay' and id ~= 'welcome' then return true end end
  return false
end

function M.requestState(id)
  consumers[id or 'angular'] = true
  uiAttached = true
  refreshMode()
  pushStatic()
  return buildStatic()
end

-- Lecture directe de l'état par l'UI (sans dépendre des événements) : sert au sondage régulier du panneau.
function M.getState()
  refreshMode()
  return buildStatic()
end

function M.uiClosed(id)
  consumers[id or 'angular'] = nil
  uiAttached = next(consumers) ~= nil
  return true
end

local SETTING_NAMES = {
  hudEnabled = 'HUD enabled', showFps = 'HUD: show FPS', showAvg = 'HUD: show average FPS', showMode = 'HUD: show game mode',
  showGraph = 'HUD: show FPS graph', compact = 'HUD: compact size', refreshRate = 'HUD refresh rate (0 = automatic)',
  accent = 'Accent color', opacity = 'HUD opacity', lang = 'Language', hudPos = 'HUD position',
  fpsOverlay = 'FPS counter', fpsBg = 'FPS counter background', fpsPos = 'FPS counter position', fpsSize = 'FPS counter size',
  fpsColor = 'FPS counter color', fpsOpacity = 'FPS counter opacity', antiStutter = 'Anti-stutter', traffic = 'Adaptive traffic',
  trafficMinFps = 'Adaptive traffic minimum FPS',
}
local function valueText(v) if v == true then return 'ON' elseif v == false then return 'OFF' end return tostring(v) end

function M.setSetting(key, value)
  if grnfr_settings.set(key, value) then
    slog('info', 'Setting changed: ' .. (SETTING_NAMES[key] or tostring(key)) .. ' is now ' .. valueText(value) .. '.')
    if key == 'hudEnabled' and value == false then hudOpen = false; bigOpen = false end
    if key == 'antiStutter' then grnfr_stutter.apply(value) end
    if key == 'traffic' then grnfr_traffic.setEnabled(value) end
    pushStatic()
  else
    slog('warn', 'A setting change was refused (' .. tostring(key) .. ' = ' .. tostring(value) .. ' is not a valid value).')
    return false
  end
  return true
end

function M.resetSettings()
  local cur = grnfr_settings.get()
  local lang, chosen, intro = cur.lang, cur.langChosen, cur.introShown -- langue et notification ne sont pas réinitialisées
  grnfr_settings.reset()
  slog('info', 'All settings were reset to their default values.')
  grnfr_settings.set('lang', lang)
  grnfr_settings.set('langChosen', chosen)
  grnfr_settings.set('introShown', intro)
  pushStatic()
  return true
end

-- Premier lancement : choix de la langue (mémorisé, l'écran d'accueil ne revient plus).
function M.chooseLanguage(lang)
  if lang ~= 'fr' and lang ~= 'en' then return end
  grnfr_settings.set('lang', lang)
  grnfr_settings.set('langChosen', true)
  slog('info', 'Language set to ' .. (lang == 'en' and 'English' or 'French') .. '.')
  pushStatic()
  return true
end

-- Appelé par le bouton du menu principal (ui/ui-vue/mods/GRNFR/index.js).
function M.showInfo()
  local msg = 'v' .. VERSION .. ' | ' .. L('Touche du HUD : ', 'HUD key: ') .. grnfr_keys.getDisplay()
    .. ' | ' .. L('HUD App : Pause > System > HUD Apps', 'HUD App: Pause > System > HUD Apps')
  pcall(function()
    guihooks.trigger('toastrMsg', { type = 'info', title = 'GRNFR Mod', msg = msg })
  end)
end

local function onStateEvent()
  refreshMode()
  pushStatic()
end

-- Changement de carte : l'état en cours (chase, trafic) est réinitialisé, mais le RÉGLAGE « trafic adaptatif »
-- reste enregistré tel que le joueur l'a choisi (il est réarmé automatiquement dans tick).
local function resetGameplayFeatures()
  grnfr_chase.stop()
  grnfr_traffic.reset()
  sessionAge = 0
end
function M.onClientStartMission() notified, notifyAcc = false, 0; resetGameplayFeatures(); onStateEvent() end
function M.onClientEndMission()
  notified, notifyAcc = false, 0
  resetGameplayFeatures()
  if wasSession then wasSession = false; pcall(grnfr_sessionlog.finish, 'The map was closed.') end
  onStateEvent()
end

M.onVehicleSwitched = onStateEvent
M.onSettingsChanged = onStateEvent
M.onInputBindingsChanged = onStateEvent

-- Hook de rendu : dtReal = durée réelle de l'image (inclut la pause).
-- onUpdate sert de repli si onPreRender n'est jamais appelé (jamais les deux).
local preRenderSeen = false
function M.onUpdate(dtReal)
  cntUpd = cntUpd + 1
  if not preRenderSeen then M.tick(dtReal) end
end
function M.onPreRender(dtReal)
  cntPre = cntPre + 1
  preRenderSeen = true
  M.tick(dtReal)
end

-- Secours : si ni onUpdate ni onPreRender ne sont jamais appelés par le jeu, l'UI appelle cette fonction à chaque image
-- et la durée est mesurée avec un chronomètre. Sans effet (renvoie 'hooks') dès que les hooks du jeu fonctionnent.
local pollTimer, inPoll, pollLogged = nil, false, false
function M.uiPoll()
  if cntPre + cntUpd > 0 then return 'hooks' end
  if not pollLogged then pollLogged = true; slog('warn', 'The game did not call the mod every frame, so FPS is now measured through the interface (backup mode). FPS numbers may be less precise.') end
  local ok, ms = pcall(function()
    if not pollTimer then pollTimer = hptimer() return nil end
    return pollTimer:stopAndReset()
  end)
  if not ok or type(ms) ~= 'number' or ms < 4 then return 'wait' end -- < 4 ms : appel en double dans la même image
  cntPoll = cntPoll + 1
  inPoll = true
  M.tick(ms / 1000)
  inPoll = false
  return 'poll'
end
-- Notification affichée UNE SEULE FOIS (introShown, mémorisé dans settings/grnfr.json), au premier lancement
-- d'une partie, quel que soit le mode de jeu.
local function notifyStart()
  local key = grnfr_keys.getDisplay()
  local msg = L('Appuyez sur ', 'Press ') .. key .. L(' pour ouvrir / fermer le HUD GRNFR.', ' to open / close the GRNFR HUD.')
    .. L(' (modifiable : Options > Contrôles > « GRNFR Mod »)', ' (changeable: Options > Controls > "GRNFR Mod")')
  pcall(function()
    guihooks.trigger('toastrMsg', { type = 'info', title = 'GRNFR Mod', msg = msg })
  end)
  grnfr_settings.set('introShown', true)
  slog('info', 'Showed the one-time tip about the HUD key.')
end

-- Chronomètre de secours : si le hook de jeu ne fournit pas de durée d'image valide, on la mesure nous-mêmes.
local timer = nil
local function fallbackDt()
  local ok, ms = pcall(function()
    if not timer then timer = hptimer() return nil end
    return timer:stopAndReset()
  end)
  if ok and type(ms) == 'number' and ms > 0 then return ms / 1000 end
end
local loggedDt = false

function M.tick(dtReal)
  if type(dtReal) ~= 'number' or dtReal ~= dtReal or dtReal <= 0 then
    dtReal = fallbackDt() or dtReal
    if not loggedDt then loggedDt = true; slog('warn', 'The game gave an invalid frame time, so the mod uses its own timer instead.') end
  elseif timer then
    pcall(function() timer:stopAndReset() end) -- garde le chronomètre synchronisé
  end
  grnfr_perf.sample(dtReal)
  do -- options en développement : trafic adaptatif et chase
    local cfg0 = grnfr_settings.get()
    local pm = grnfr_perf.get()
    if cfg0.traffic then
      grnfr_traffic.update(tonumber(dtReal) or 0, pm and pm.avg or nil, cfg0.trafficMinFps)
      -- état « impossible » : on le laisse affiché (le réglage reste coché), le changement d'état est poussé à l'UI par la signature
    end
    grnfr_chase.update(tonumber(dtReal) or 0)
  end
  if wasSession then grnfr_sessionlog.update(tonumber(dtReal) or 0, (grnfr_perf.get() or {}).avg) end
  if modeInfo.session then
    if not notified and not grnfr_settings.get().introShown then
      notifyAcc = notifyAcc + (tonumber(dtReal) or 0)
      if notifyAcc >= 5 then -- laisse le temps au mode (jeu libre / carrière) de se stabiliser
        notified = true
        refreshMode()
        if modeInfo.session then notifyStart() end
      end
    end
  else
    notified, notifyAcc = false, 0
  end
  local dt = tonumber(dtReal) or 0
  acc, modeAcc = acc + dt, modeAcc + dt
  if modeInfo.session then sessionAge = sessionAge + dt else sessionAge = 0 end
  local cfg = grnfr_settings.get()
  -- cadence de mise à jour du HUD : 0 = automatique (à chaque image, aucune limite), sinon N fois par seconde
  local period = (cfg.refreshRate or 0) > 0 and 1 / cfg.refreshRate or 0
  if not needFast() then period = 0.5 end -- compteur FPS / fenêtre : une valeur toutes les 0,5 s suffit
  if modeAcc >= 1 then -- le mode de jeu est relu une fois par seconde (pas à chaque image)
    modeAcc = 0
    refreshMode()
    -- réglage trafic enregistré = coché : on (ré)arme le trafic adaptatif quelques secondes après l'entrée en partie
    if modeInfo.session and sessionAge >= 5 and grnfr_settings.get().traffic and grnfr_traffic.status().state == 'off' then
      grnfr_traffic.setEnabled(true)
    end
    local tr = grnfr_traffic.status()
    local sig = table.concat(modeInfo.ids or {}, '+') .. tostring(modeInfo.raw) .. tostring(modeInfo.session)
      .. '|' .. tr.state .. tr.active .. '/' .. tr.parked .. '|' .. grnfr_chase.status().phase
    staticAcc = staticAcc + 1
    if sig ~= lastSig or staticAcc >= 1 then lastSig = sig; staticAcc = 0; pushStatic() end
  end
  if acc < period then return end
  acc = period > 0 and math.min(acc - period, period) or 0 -- garde le reste : la limite est respectée au plus près
  local m = grnfr_perf.get()
  cntSent = cntSent + 1
  guihooks.trigger('GRNFRTick', {
    poll = inPoll,
    hooks = cntPre + cntUpd,
    valid = m ~= nil,
    fps = m and m.instant or 0,
    avg = m and m.avg or 0,
    frames = m and m.frames or 0,
  })
end

function M.onExtensionLoaded()
  pcall(function() grnfr_stutter.apply(grnfr_settings.get().antiStutter) end)
end

function M.onExtensionUnloaded()
  pcall(grnfr_settings.flush)
  wasSession = false
  pcall(grnfr_sessionlog.finish, 'The mod was unloaded.')
  pcall(grnfr_chase.stop)
  pcall(grnfr_stutter.apply, false)
  if guihooks then guihooks.trigger('GRNFRStatic', { session = false, hudOpen = false }) end
  grnfr_perf.reset()
end

return M
