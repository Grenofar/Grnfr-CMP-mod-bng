# GRNFR Mod

Shows your FPS and current game mode in an in-game HUD, with a settings window (main menu / pause menu), an in-game window and an optional always-visible FPS counter.
It also adds two experimental options: **Adaptive traffic** and **Chase** (two modes).

## How to use
| I want to... | Do this |
|---|---|
| Open or close the small HUD (in a map) | Press **K** (change it in Options > Controls > "GRNFR Mod") |
| Open the in-game window (Gameplay, Adaptive traffic, Anti-stutter) | Small HUD > **Option** button (press K to close it) |
| Change settings (HUD, FPS counter, language) | Main menu > **GRNFR Mod**, or Pause menu > **Mods** tab > GRNFR Mod |
| Start a chase (free roam only) | In-game window > **Gameplay** tab: **"the police chase you"** or **"you are the police"**, then a **3-2-1-GO** countdown starts by itself |

English and French are available (choose on first launch, change any time in Settings).

## Your settings
All settings are saved to disk automatically in `settings/grnfr.json` (inside your BeamNG user folder).
They are kept between maps and game restarts. Delete that file to go back to the defaults.

## Session logs (if something does not work)
Every time you play a map, the mod writes a short, plain-English diary of what happened to:

`<BeamNG user folder>/settings/grnfr/logs/`

One text file per session, named by date and time. The 10 newest are kept. Lines starting with `WARNING` or `PROBLEM`
are the ones that matter. If you report a bug, please attach the latest file.

The logs contain **no personal data**: no user name, no folder paths and no PC hardware information.
The mod collects nothing and sends nothing over the network.

## Notes
- Adaptive traffic, Anti-stutter and Police chase are experimental and rely on game features that may differ between game versions.
- Chase: you start it from the in-game window, which closes by itself while the small HUD appears. The game pauses, a 3-2-1-GO countdown runs, both cars stay still until GO, then both start moving.
  - "The police chase you": an AI police car matching your car's performance appears next to you and chases you.
  - "You are the police": an AI suspect with the same power as your car appears in front of you and runs away. Catch it!

---

## Roadmap (planned, NOT implemented yet)

These are the long-term goals for GRNFR Mod. Nothing below exists in the current version. The order is the planned order of work, from the simplest and safest to the riskiest.

**Guiding principles**
- All code and all interfaces are written from scratch for this mod. No BeamNG game files are copied or redistributed, and the game's own career files are never modified. Before publishing any new part, the BeamNG modding guidelines are checked again.
- The mod runs on a BeamMP server (BeamNG has no built-in multiplayer). Anything involving money is stored and checked **on the server**, never trusted from the player's computer, so it cannot be cheated.
- Everything is tested on the West Coast, USA map first.

**Step 1 - Shared economy (server side)**
- A money account for every player, saved on the server between sessions.
- Give or send money to another player on the server.
- Simple, readable rules for earning and spending, configurable by the server owner.

**Step 2 - Taxi mode**
- Passengers appear at random places, but only at believable ones: roads, parking lots, businesses and other points of interest. Never in the middle of nowhere.
- Each passenger chooses a destination that is also a believable place.
- You are paid every time a passenger is dropped off, and every time a package is delivered.
- Money is paid by the server only after the ride or delivery is really completed.

**Step 3 - Calling a taxi**
- A phone-style interface with a map: call a taxi, see it coming, choose your destination and pay.
- Other players who work as taxi drivers can accept the calls.

**Step 4 - Dealerships and private sales**
- Several car dealerships, each with its own cars and prices.
- Private sales between players: list a car, set a price, negotiate, and swap the car and the money at the same time.

**Step 5 - AI taxis (bots)**
- Bot-driven taxis that drive around and can be called like player taxis.
- This is the hardest part in multiplayer: every player must see the same bot at the same place. It will be tested carefully before anything is promised.

**Step 6 - A full career of our own (long term)**
- A separate career, with its own save files, completely independent from the BeamNG career, so the two never mix.
- Its own interface, with a garage computer in several garages on the West Coast map.
- Garages and cars belong to each player on the server.

**Smaller ideas for the current features**
- Chase: win and lose conditions (catching the suspect, losing the police), a score, and a difficulty setting.
- Chase: choose the police car or the suspect car yourself.
- Session logs: a button to open the log folder.

## Contributing / feedback
If something does not work, attach the latest session log (see above) to your report. Suggestions for the roadmap are welcome.
